package com.inautix.training.counselling.exception;

public class noteligibleexception extends Exception{
	public String notEligibleException()
	{
		return "YOU ARE NOT ELIGIBLE FOR THE COLLEGE / COURSE ...";
	}
}
