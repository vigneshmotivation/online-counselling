package com.inautix.training.counselling.exception;

public class sqlException extends Exception {

	public String sqlException()
	{
		return "sql statement execution failed";
	}
}
