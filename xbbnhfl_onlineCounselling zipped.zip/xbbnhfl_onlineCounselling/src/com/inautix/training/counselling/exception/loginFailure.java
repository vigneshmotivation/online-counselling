package com.inautix.training.counselling.exception;

public class loginFailure extends Exception {
	
	public String loginException ()
	{
		return "USER NAME / PASSWORD INVALID.... PLEASE TRY AGAIN ! ";
	}

	
}

